package com.Basic_Proj.ReportDownload_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportDownloadBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportDownloadBackendApplication.class, args);
	}

}
