package com.Basic_Proj.ReportDownload_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportDownloadBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
